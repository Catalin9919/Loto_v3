import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class Loto649 {
	
	private File f = new File("~/Documents/JavaGoogle/CsEx/Loto 6din49 v2/src/649.txt");
	private File g = new File("~/Documents/JavaGoogle/CsEx/Loto 6din49 v2/src/540.txt");
	private PrintWriter output1;
	private PrintWriter output2;
	
 	
	public void showResults(int optionFileToReadFrom) { // 1-649, 2-540
		
		switch (optionFileToReadFrom)
		{
		case 1:
			try {
				Scanner sc1 = new Scanner(f);
			} catch (FileNotFoundException e) {
				e.getMessage();
			}
			
			
			
			break;
			
		case 2:
			try {
				Scanner sc2 = new Scanner(g);
			} catch (FileNotFoundException e) {
				e.getMessage();
			}
			break;
		}
	}
	
	public void writeInFile(int[] array, int optionFileToWriteIn) { //1-649, 2-540
		
		switch(optionFileToWriteIn) {
		
		case 1:
				try {
					output1 = new PrintWriter(f);
					for(int i=0;i<array.length;i++)
						output1.println(array[i]+" ");
					output1.close();
				} catch (IOException e) {
					e.getMessage();
				}
			break;
				
		case 2:
				try {
					output2 = new PrintWriter(g);
					for(int i=0;i<array.length;i++)
						output2.println(array[i]+" ");
					output2.close();
				} catch (IOException e) {
					e.getMessage();
				}
			break;
		
		}
		
	}
	
	public static int[] genNumb(int nr, int min, int max) {
		
		Random rand = new Random();
		int[] numbers=new int[nr];
		int currentNumber;
		
		for(int i=0;i<numbers.length;i++) {
			currentNumber=rand.nextInt(max)+min;
			if(contains(currentNumber,i,numbers)) {
				i--;
			}
			else {
				numbers[i]=currentNumber;
			}
			
		}
		
		return numbers;
		
	}
	
	public static boolean contains(int nr, int poz, int[] currentArray) {
		
		for(int i=0;i<poz;i++)
			if(currentArray[i]==nr)return true;
		
		return false;
		
	}
	
	public int CommonNumbersCount(int[] numbers, int[] numbers1) {
		
		int contor = 0;
		
		for(int i=0;i<numbers.length;i++) {
			
			if(contains(numbers[i], numbers.length,numbers1)) {
				contor++;
			}
			
		}
		
		return contor;
		
	}
	
	public static void main(String[] args) {
		
		
		
	}
	

}
